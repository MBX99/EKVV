﻿namespace EKVV_SIK
{
  public enum Frequency
  {
    MINUTELY,
    HOURLY,
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY
  }
}
