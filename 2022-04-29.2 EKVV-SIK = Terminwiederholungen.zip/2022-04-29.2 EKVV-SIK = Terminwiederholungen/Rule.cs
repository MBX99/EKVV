﻿using System;

namespace EKVV_SIK
{
  public class Rule
  {
      private Frequency frequency { get; set; }
      private DateTime until { get; set; }
      private int interval { get; set; }
  }
}
