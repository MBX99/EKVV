﻿using System;

namespace EKVV_SIK
{
  public class Termin
  {
    //leere vorlage, getter setter usw. fehlen evtl. construktor und weitere methoden
    private DateTime start { get; set; }
    private DateTime end { get; set; }
  }


}
