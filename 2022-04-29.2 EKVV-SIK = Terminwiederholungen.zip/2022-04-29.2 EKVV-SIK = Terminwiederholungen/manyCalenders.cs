﻿using System;

namespace EKVV_SIK
{
    internal class manyCalenders
    {
        private DateTime DtStart { get; set; }
        private DateTime DtEnd { get; set; }
        private Rule Rule { get; set; }
    }
}